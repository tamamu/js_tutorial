This is a fork of Chuck Rhode's `PythonTidy <http://lacusveris.com/PythonTidy/>` script.
The complete version history was imported from http://lacusveris.com/PythonTidy/.

Please see http://pypi.python.org/pypi/PythonTidy/ for more information.
